// element - DOMHTMLElement that triggered this function being called
// event - event that triggered this function being called
function ${functionName}(${arguments}) {
	
	
}
